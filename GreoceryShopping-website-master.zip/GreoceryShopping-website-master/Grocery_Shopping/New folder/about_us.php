<!DOCTYPE html>
<html lang="en">
<head>
   
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/contactus.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/cb4a67ae30.js" crossorigin="anonymous"></script>
</head>
<body>
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark">

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="home.php">Home</a>
                        </li>
                       
                       
                            <li class="nav-item active">
                                <a class="nav-link" href="about_us.php">About Us</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="jumbotron big-banner">
                   <div class="container">
                       <div class="row">
                           <div class="col-sm-6">
                              <h4> Lorem ipsum dolor sit amet consectetur 
                              adipisicing elit. Nobis repudiandae commodi quidem eligendi, id nam aliquid 
                              sapiente, laudantium dolor quia doloribus dolorum eos animi neque! Quis nulla facilis nobis atque. </h4>
                           </div>
                       </div>
                   </div>
    
                
                </div>
      
                
        <!-- footer -->
        <footer>
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-one">
                            <h3>Our Shop</h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut libero
                                laboriosam tempore praesentium ea expedita tenetur ex accusamus temporibus
                                laudantium officia vitae quaerat minima quibusdam rem dolor doloremque,
                                repudiandae esse.
                            </p>

                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-12 segment-two">
                            <h2>Divinector</h2>
                            <ul>
                                <li><a href="#"></a>Event</li>
                                <li><a href="#"></a>Support</li>
                                <li><a href="#"></a>Hosting</li>
                                <li><a href="#"></a>Career</li>
                                <li><a href="#"></a>Blog</li>
                            </ul>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-12 segment-three">
                            <h2>Follow Us</h2>
                            <p>Please Follow Us On Social Media</p>
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-four">
                            <h2>Our Newsletter</h2>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At vero nobis
                                repellat totam eos distinctio, exercitationem veritatis, odit temporibus
                                eius expedita ratione quam mollitia impedit quo nemo ex dolor ullam.</p>
                            <form action="">
                                <input type="email">
                                <input type="submit" value="subscribe">
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <p class="footer-bottom-text">All Right reserved by &copy; Our Shop.2019</p>
        </footer>
    
</body>
</html>