
<?php
session_start();
  require_once 'config/config.php';

?>


<?php

	//log in thekeo abar log in korte chaile
	if(isset($_SESSION['username'])){
		$_SESSION['try-to-login-again'] = true;
		header("location: home.php");
	}


	if(isset($_SESSION['not-logged-in'])){
		echo '<script language="javascript">';
		echo 'var r =confirm("you are not logged in, please log in");';
		echo '</script>';
		unset($_SESSION['not-logged-in']);
	}
?>






<!DOCTYPE html>
<html>
<head>
<title>Login page</title>


<link rel="stylesheet" href="css/login.css">
<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

</head>
<body style = " background: linear-gradient(to right, #28a745 0%, white 80%) ;">

<div id = "main-wrapper">
    <center>
        <h2 class="text" ><b>Log in here!!</b></h2>
        <p class="text" >Please insert your username and password</p>
        <img src="image/login.jpg" class="loginimage"/>
    </center>
   <form class = "myform" action="login.php" method = "post">
          <label class="text"><b>Email :</b> </label>
          <input name = "email" type="text" class="inputvalues" placeholder="Type your email" required/><br>
          <label class="text"> <b>Password : </b> </label>
          <input name="password" type="password" class="inputvalues" placeholder="Type password" required/><br>
            <input class="button" name="login" type="submit" id = "login_btn" value="Login"/> <br>
            <a href="register.php"><input class="button" type="button" id = "register_btn" value="Not register!?  Regester Here"/></a>
    
            <a href="home.php"><input class="button" type="button" id = "register_btn" value="Homepage"/></a>
           
     </form>
<?php
 if(isset($_POST['login'])){
	$email 			= htmlspecialchars(stripslashes(trim($_POST['email'])));
	$password 		= htmlspecialchars(stripslashes(trim($_POST['password'])));

	$password = md5($password);
	$sql = "SELECT * FROM user WHERE email='$email' AND password='$password'"
					or die("failed to execute".mysqli_errno());
	$result = mysqli_query($con,$sql);

	// if(true){
	// 	echo '<script language="javascript">';
    // 	echo 'alert("Wrong adminName & Password Combination")';
    // 	echo '</script>';
	// }
	$row = mysqli_fetch_array($result);
		
		
		$_SESSION['email'] = $email;
		$_SESSION['username'] = $row['username'];
		$_SESSION['user_id'] = $row['user_id'];
		$_SESSION['phone'] = $row['phone'];
	

	if(mysqli_num_rows($result) == 1){

		$_SESSION['message'] = "you are logged in";
		header("location: home.php");
	} else {
		echo "not found account";
	}
}
?>

</div>

    
</body>
</html>