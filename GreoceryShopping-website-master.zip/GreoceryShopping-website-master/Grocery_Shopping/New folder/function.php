<?php
  require 'config/config.php';
  //session_start();

function order()
{

   
    
      global $con;
      if(isset($_GET['nocheckout']))
      {
        echo "<script>window.open('login.php','_self')</script>";  
      
      }


      if(isset($_GET['checkout'])){
        if(isset($_SESSION['username'])){
            $username = $_SESSION['username'];
            for($i=0;$i<sizeof($_SESSION['shopping_cart']); $i++){
                
                $b = $_SESSION['shopping_cart'][$i]['product_title']; 
                $c = $_SESSION['shopping_cart'][$i]['product_price']; 
                $d = $_SESSION['shopping_cart'][$i]['quantity']; 
                $e = $d * $c; 
                $sql = "INSERT INTO `ordertable`(`username`, `product_title`, `quanity`, `price`) 
                VALUES ('$username','$b','$d','$c')" or die("something is wrong");
                $result = mysqli_query($con, $sql);

                
            }
            if(isset($result) && $result==true ){
              echo "<script>alert('Your Order is confirmed')</script>"; 
               // echo "done";
                //unset($_SESSION['shopping_cart']);
                $_SESSION['shopping_cart'] =[];
                $_SESSION['totalamount']=[];

                echo "<script>window.open('home.php','_self')</script>";  
               
   
           
            } else {
             // header("location: home.php");
                echo "wrong";
            }
        }
        else {
    
        }
    }

     

      


     
    }



















  ?>