
<?php
  require 'config/config.php';
  //require 'config/functions.php';
  session_start();
  //echo  $_SESSION['username'];

  if(isset($_SESSION['username'])){
    $username = $_SESSION['username'];
  } else{
    $username = ' ';
  }




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spreads</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/stylesheet.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/cb4a67ae30.js" crossorigin="anonymous"></script>

</head>

<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">

    <li class="nav-item active">
            <a class="nav-link" href="">Welcome  <?php echo $username?></a>
        </li>


    
        <li class="nav-item active">
            <a class="nav-link" href="home.php">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                data-toggle="dropdown">
                My Account
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="login.php">Login</a>
                
        </li>
        
        <li class="nav-item active">
            <a class="nav-link" href="contact_us.php">Contact Us</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="about_us.php">About Us</a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
    </ul>
</div>
</nav>
     <!-- search box -->
     <div class="top-nav-bar">
                <div class="search-box">
                   
                    <img src="image/logo1.jpg" class="logo">
                    <form action="searchlogic.php" method="post">
                        
                        <span><input type="text" name="search" placeholder="Search" class="mt-3 searchInput"/></span>
                        <span><button style="background-color: orange"> <i class="fas fa-search"></i></button></span>
                        
                    </form>
                </div>
                <div class="cart-bar mt-1">
                    <ul>
                        <li class="cart_basket"><a href="cart.php"><i class="fas fa-shopping-basket"></i>cart</a></li>

                        
                    </ul>
                </div>
            </div>
<form action="cat_selected.php?action=add&id=<?php echo $cat_id ?>" method = "get">
    <div class="container">
    <div class="row">



    <!-- category er vitore jeisob product ache ogula show krbe category click korle -->

<?php

if(isset($_GET['cat']))
    {
      $cat_id = $_GET['cat'];
      $get_cat_pro = "select * from products where cat_id='$cat_id'";
       $run_cat_pro = mysqli_query($con,$get_cat_pro);
      $count = mysqli_num_rows($run_cat_pro);

    if($count==0)
      {
           echo "<h4> no products found in this category</h4>";
      }


     while($row_cat_pro=mysqli_fetch_array($run_cat_pro))
     {
    $pro_id = $row_cat_pro['product_id'];
   $pro_title = $row_cat_pro['product_title'];
   $pro_cat = $row_cat_pro['cat_id'];
   $pro_desc = $row_cat_pro['product_desc'];
   $pro_price = $row_cat_pro['product_price'];
   $pro_img = $row_cat_pro['product_img'];

echo"
<div class='col-md-4'>
<div class='card'>
<div class='inner'>
<a  href='details.php?pro_id=$pro_id'> <img src='insert image/$pro_img' class='card-img-top'></a>
</div>

<div class='card-body text-center'>
<h5 class='card-title'>$pro_title</h5>
<h5 class='card-text'>$pro_price TK</h5>
<a  href='cart.php?pro_id=$pro_id'  class='btn btn-success'>Add To Cart</a>
</div>
</div>
</div>



";
}

}


?>
</div>
       
        </div>
    </div>
</form>


</body>

</html>