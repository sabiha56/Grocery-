<?php
  require 'config/config.php'

  //session_start();

?>




<!DOCTYPE html>
<html>
<head>
<title>Registration page</title>

<link rel="stylesheet" href="css/login.css">

</head>
<body style = " background: linear-gradient(to right, #f7ca66 0%, white 100%) ">

<div id = "main-wrapper">
    <center>
        <h2 class="text" > Register here !!</h2>
        <p class="text" >Please insert your name and password to register</p>
        <img src="image/register.jpg" class="loginimage"/>
    </center>
   <form class = "myform"   action="register.php" method = "post">
          <label class="text"><b> Username :</b> </label>
          <input name="username" type="text" class="inputvalues1" placeholder="Type username"required/><br> 
          <label class="text"><b> Email :</b> </label>
          <input name="email" type="text" class="inputvalues1" placeholder="Type email"required/><br> 

          <label class="text"><b> City :</b> </label>
                 <select name="city" class="inputvalues1"required><br> 
                    <option value="Dhaka">Dhaka</option>
                    <option value="Chittagong">Chittagong</option>
                    <option value="Syllet">Syllet</option>
                    <option value="Mymensingh">Mymensingh</option>
                    <option value="Brishal">Brishal</option>
                  </select>


          <label class="text"> <b>Password : </b> </label>
          <input name="password" type="password" class="inputvalues1" placeholder="Type password"required/><br>

          <label class="text"> <b>Confirm Password : </b> </label>
          <input name="confirm_password" type="password" class="inputvalues1" placeholder="Type password again"/><br>

          <label class="text"><b> Contact No :</b> </label>
          <input name="phone" type="text" class="inputvalues1" placeholder="phone numnber"required/><br> 

          <label class="text"><b> Address :</b> </label>
          <input name="address" type="text" class="inputvalues1" placeholder=""required/><br> 

            <input class="button" name="submit_btn" type="submit" id = "signup_btn" value="Sign Up"/> <br>
           <a href="login.php"> <input class="button" type="button" id = "back_btn" value="Go to Login page"/></a>
         
           <a href="home.php"> <input class="button" type="button" id = "back_btn" value="Homepage"/></a>
           
     </form>

</div>

    
</body>
</html>



<?php 



if(isset($_POST['submit_btn'])) {
	session_start();

	$username 		= htmlspecialchars(stripslashes(trim($_POST['username'])));
	$email 			= htmlspecialchars(stripslashes(trim($_POST['email'])));
	$phone 			= htmlspecialchars(stripslashes(trim($_POST['phone'])));
	$password 		= htmlspecialchars(stripslashes(trim($_POST['password'])));
	$confirm 		= htmlspecialchars(stripslashes(trim($_POST['confirm_password'])));

	if($password == $confirm){
    $password = md5($password);
    

    $sql = " INSERT INTO `user`(`username`, `email`, `phone`, `password`) VALUES ('$username', '$email', $phone, '$password')";

		mysqli_query($con, $sql);
		$_SESSION['message'] = 'you are logged in successfully';
		$_SESSION['username'] = $username;
		$_SESSION['email'] = $email;
		header('location: home.php');

	} else {
		$_SESSION['message'] = 'password didnt match';
	}
}

?>