
<?php
  require 'config/config.php';
  require_once 'function.php';
  session_start();
  //echo  $_SESSION['username'];
?>


<?php
        if(isset($_SESSION['email'])){
          $user_email = $_SESSION['email'];
        } else{
          $user_email = 'Log in for order';
        }

        if(isset($_SESSION['username'])){
          $username = $_SESSION['username'];
          $login = 1;
        } else{
          $username = ' ';
        }
        if(isset($_SESSION['total_money']))
        {
            $total = $_SESSION['total_money'];
        }
        else
        {
            $total = '0';
        }

     

        
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Cart</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/cartpage.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/cb4a67ae30.js" crossorigin="anonymous"></script>

</head>

<body>

    <body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">

    <li class="nav-item active">
            <a class="nav-link" href="">Welcome  <?php echo $username ?></a>
        </li>
        


<!--------------user profile-------------->
        
<?php   if(isset($_SESSION['username'])){  ?>


        <li class="nav-item active">
            <a class="nav-link" href="user_profile.php"> <i class="fa fa-user-o" aria-hidden="true"></i>  </a>
        </li>


<?php      } 

else{   ?>


<li class="nav-item active">
            <a class="nav-link" href="login.php"> <i class="fa fa-user-o" aria-hidden="true"></i>  </a>
        </li>


<?php
} ?>
       
<!--------------user profile-------------->




    
        <li class="nav-item active">
            <a class="nav-link" href="home.php">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                data-toggle="dropdown">
                My Account
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="login.php">Login</a>
                
        </li>
        
        <li class="nav-item active">
            <a class="nav-link" href="contactus.php">Contact Us</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="about_us.php">About Us</a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
    </ul>
</div>
</nav>
        <!-- search box -->
        <div class="top-nav-bar">
                <div class="search-box">
                   
                    <img src="image/logo1.jpg" class="logo">
                    <form action="searchlogic.php" method="post">
                        
                        <span><input type="text" name="search" placeholder="Search" class="mt-3 searchInput"/></span>
                        <span><button style="background-color: orange"> <i class="fas fa-search"></i></button></span>
                        
                    </form>
                </div>
                <div class="cart-bar mt-1">
                    <ul>
                        <li class="cart_basket"><a href="cart.php"><i class="fas fa-shopping-basket"></i>cart</a></li>

                        
                    </ul>
                </div>
            </div>


    <div class="container">
            <div class="row">
                    <div class="col-md-2 col-md-offset-1">
                            <h4>Product Name</h4>
                        </div>
                        <div class="col-md-2 col-md-offset-1">
                                <h4>Unit Price</h4>
                            </div>
                        <div class="col-md-2 col-md-offset-1">
                                <h4>Quantity</h4>
                            </div>
                            <div class="col-md-2 col-md-offset-1">
                                    <h4>Total Price</h4>
                                </div>
                                <div class="col-md-2 col-md-offset-1">
                                    <h4>Remove</h4>
                                </div>

                            
            </div>
            </div>
        </div>
    

<!-- cart e add korar pore product er details astese -->


<?php






$product_ids = array();

if(isset($_GET['pro_id'])){

    $pro_id = $_GET['pro_id'];
   // echo $_GET['pro_id'];
  // echo $pro_id;

  $get_product_details = "select * from products where product_id='$pro_id' ";
  $run_product_details = mysqli_query($con,$get_product_details);


  while($row_product_details=mysqli_fetch_array($run_product_details))
    {
        $pro_id = $row_product_details['product_id'];
        $pro_title = $row_product_details['product_title'];
        
        $pro_price = $row_product_details['product_price'];  
        
        $quantity = '1';
    
    }
    //echo $pro_title;
 // session_start();

////////////////////////////////////////////sob product er details nilam ebar session e rakhbo


//jodi age theke kono session  thake


if(isset($_SESSION['shopping_cart'])) {
    $count = count($_SESSION['shopping_cart']);
    $product_ids = array_column($_SESSION['shopping_cart'], 'id');


    if(!in_array(filter_input(INPUT_GET, 'id'), $product_ids)){
        $_SESSION['shopping_cart'][$count] = array
            (
                'product_id' 		=> $pro_id,
                'product_title' 	    => $pro_title,
                'product_price'	    => $pro_price,
                'quantity'         =>  $quantity
            );
    } else {
        for($i=0; $i < count($product_ids); $i++){
            if($product_ids[$i] == $pro_id){
                $_SESSION['shopping_cart'][$i]['quantity'] += $quantity;
            }
        }
    }
    
   // header("location: home.php");

   echo "<script>window.open('home.php','_self')</script>";    

}
//jodi session na thake
else {
    $_SESSION['shopping_cart'][0] = array
    (
        'product_id' 		=> $pro_id,
        'product_title' 	    => $pro_title,
        'product_price'	    => $pro_price,
        'quantity'         =>  $quantity
    );
   // header("location: home.php");
   echo "<script>window.open('home.php','_self')</script>";    
}


}

/*  test korar jonno product details astese kina




if(isset($_SESSION['shopping_cart'])){
    pre_r($_SESSION['shopping_cart']); 
} else {
    echo "cart empty";
}



function pre_r($array){
	echo "<pre>";
	print_r($array);
    echo "</pre>";
   
}
*/

?>

  <!-- ////////////////////////////////product dekhano -->
<form action="" method="">
 



<?php



if(!empty($_SESSION['shopping_cart'])){

    $total = 0;
    $_SESSION['total_money'] = $total;
    foreach($_SESSION['shopping_cart'] as $key => $product) 
    {  ?>





    <div class="container">
        <div class="row">
            
                    <div class="col-md-2 col-md-offset-1">
                            <h5><?php echo $product['product_title']; ?></h5> <br>
                        </div>
                        <div class="col-md-2 col-md-offset-1">
                                <h5><?php echo $product['product_price']."  TK"; ?></h5>  <br>
                            </div>

                            <div class="col-md-2 col-md-offset-1">
                                <h5><?php echo $product['quantity' ]; ?></h5> <br>
                            </div>
                      
                            <div class="col-md-2 col-md-offset-1">
                                    <h5><?php echo number_format($product['quantity'] * $product['product_price'], 2)  ." TK"; ?></h5> <br>
                                </div>


   <?php                    
//////////////////////////datbase e order neoo



order();

///////////////////////order ses datbase 
?>
                          <div class="col-md-2 col-md-offset-1">
                          <a href="cart.php?action=delete&id=<?php echo $product['product_id']; ?>">
							<div class="btn btn-success" style = "background-color:red;">Remove</div>
						</a>




                            </div>
                                
               
        </div>
    </div>

  

        <?php



$total += $product['product_price'];





    }
  


}


////////////////////product dekhano ses 


?>

<!-------------------------------delete from shopping cart --------------------->

<?php
	if(filter_input(INPUT_GET, 'action') == 'delete'){
		foreach($_SESSION['shopping_cart'] as $key => $product){
			if($product['product_id'] == filter_input(INPUT_GET, 'id')){
				unset($_SESSION['shopping_cart'][$key]);
            }
 

		}

		$_SESSION['shopping_cart'] = array_values($_SESSION['shopping_cart']);
	}
?>




<!------------------------------total amount dekhano--------------------->
<?php

 //   $total=0;
    
 //   $total = $total + ($product['quantity'] * $product['product_price']);
  //  $_SESSION['total_money'] = $total; 

  $_SESSION['totalamount'] = $total;


?>


    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div style = "margin-top: 70px;font-"> <b><h1>Total Amount</h1> </b></div>
         
                <h4><?php echo number_format($total, 2)."  TK"; ?></h4>
              
               <?php  if(isset($_SESSION['username'])){
                   
                   ?>

                     <form action="" method="GET">
                <input type="submit" style = "background-color:blue;" name='checkout' class="btn btn-info" value="Checkout" />
                </form>

              <?php  } 
              else
              {?>

               <form action="" method = "GET">
            
               <input type="submit" style = "background-color:red;" name='nocheckout' class="btn btn-info" value="Please Log in For order" />  
               </form>


             <?php } ?>
               
               
            </div>
        </div>
    </div>

   
        <!-- footer -->
        <footer>
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-one">
                            <h3>Our Shop</h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut libero
                                laboriosam tempore praesentium ea expedita tenetur ex accusamus temporibus
                                laudantium officia vitae quaerat minima quibusdam rem dolor doloremque,
                                repudiandae esse.
                            </p>

                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-12 segment-two">
                            <h2>Divinector</h2>
                            <ul>
                                <li><a href="#"></a>Event</li>
                                <li><a href="#"></a>Support</li>
                                <li><a href="#"></a>Hosting</li>
                                <li><a href="#"></a>Career</li>
                                <li><a href="#"></a>Blog</li>
                            </ul>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-12 segment-three">
                            <h2>Follow Us</h2>
                            <p>Please Follow Us On Social Media</p>
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 segment-four">
                            <h2>Our Newsletter</h2>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At vero nobis
                                repellat totam eos distinctio, exercitationem veritatis, odit temporibus
                                eius expedita ratione quam mollitia impedit quo nemo ex dolor ullam.</p>
                            <form action="">
                                <input type="email">
                                <input type="submit" value="subscribe">
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <p class="footer-bottom-text">All Right reserved by &copy; Our Shop.2019</p>
        </footer>







        </body>
  

</html>