-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2019 at 04:16 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Baby Food and Care'),
(2, 'Chocolates'),
(3, 'Fruits And Vegetables'),
(7, 'Meat & Fish'),
(8, 'Dairy Products'),
(9, 'Cooking Essentials'),
(10, 'Personal Care'),
(11, 'Other Foods');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Subject` varchar(100) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `username`, `Email`, `Subject`, `Message`) VALUES
(1, '', '', '', ''),
(2, 'sadia', 'sadiatasnim019@gmail.com', 'review', 'where is your location?'),
(3, 'sadia', 'sadiatasnim019@gmail.com', 'review', 'where is your location?'),
(4, 'sadia', 'sadiatasnim019@gmail.com', 'review', 'where is your location?'),
(5, 'sadia', 'sadiatasnim019@gmail.com', 'review', 'where is your location?'),
(6, 'sadia', 'sadiatasnim019@gmail.com', 'review', 'adsetfsdwgtfersdgt4ersgers'),
(7, 'sabiha', 'sabiha@gmail.com', 'product', 'where is my product?');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `product` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`product`) VALUES
('Kitkat'),
('Kitkat'),
('Kitkat'),
('Hilsha Fish'),
('Beef'),
('Coffee Mate'),
('Kitkat'),
('Hilsha Fish'),
('Beef'),
('Coffee Mate'),
('Kitkat'),
('Hilsha Fish'),
('Beef'),
('Coffee Mate'),
('Kitkat'),
('Hilsha Fish'),
('Beef'),
('Coffee Mate');

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE `ordertable` (
  `order_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `quanity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`order_id`, `username`, `product_title`, `quanity`, `price`) VALUES
(2, 'rifat', 'Hilsha Fish', 1, 500),
(3, 'rifat', 'Beef', 1, 470),
(4, 'rifat', 'Coffee Mate', 1, 200),
(5, 'rifat', 'Kitkat', 1, 65),
(6, 'rifat', 'Cerelac', 1, 200),
(7, 'rifat', 'Bread', 1, 200),
(8, 'rifat', 'Cerelac', 1, 200),
(126, 'rifat', 'Hilsha Fish', 1, 500),
(127, 'rifat', 'Shampoo', 1, 550),
(128, 'rifat', 'Beef', 1, 470),
(129, 'rifat', 'Coffee Mate', 1, 200),
(130, 'rifat', 'Shampoo', 1, 550),
(131, 'rifat', 'Kitkat', 1, 65),
(132, 'rifat', 'Cerelac', 1, 200),
(133, 'rifat', 'Beef', 1, 470),
(134, 'rifat', 'Shampoo', 1, 550),
(135, 'rifat', 'Hilsha Fish', 1, 500),
(136, 'rifat', '', 0, 0),
(137, 'rifat', '', 0, 0),
(138, 'rifat', 'Hilsha Fish', 1, 500),
(139, 'rifat', 'Shampoo', 1, 550),
(140, 'rifat', 'Beef', 1, 470),
(141, 'rifat', 'Hilsha Fish', 1, 500),
(142, 'rifat', 'Hilsha Fish', 1, 500),
(143, 'rifat', 'Shampoo', 1, 550),
(144, 'rifat', 'Bread', 1, 200),
(145, 'rifat', 'Kitkat', 1, 65),
(146, 'rifat', 'Cerelac', 1, 200),
(147, 'rifat', 'Cerelac', 1, 200),
(148, 'rifat', 'Shampoo', 1, 550),
(149, 'rifat', 'Bread', 1, 200),
(150, 'rifat', 'Kitkat', 1, 65),
(151, 'rifat', 'Beef', 1, 470),
(152, 'rifat', 'Kitkat', 1, 65),
(153, 'rifat', 'Cerelac', 1, 200),
(154, 'rifat', 'Beef', 1, 470),
(155, 'rifat', 'Cerelac', 1, 200),
(156, 'rifat', 'Beef', 1, 470),
(157, 'rifat', 'Shampoo', 1, 550),
(158, 'rifat', 'Coffee Mate', 1, 200),
(159, 'rifat', 'Kitkat', 1, 65),
(160, 'rifat', 'Beef', 1, 470),
(161, 'rifat', 'Hilsha Fish', 1, 500),
(162, 'rejwan', 'Coffee Mate', 1, 200),
(163, 'rejwan', 'Shampoo', 1, 550),
(164, 'sadia', 'Cerelac', 1, 200),
(165, 'sadia', 'Beef', 1, 470),
(166, 'sadia', 'Beef', 1, 470),
(167, 'sadia', 'Kitkat', 1, 65),
(168, 'sadia', 'Beef', 1, 470),
(169, 'sadia', 'Kitkat', 1, 65),
(170, 'sadia', 'Beef', 1, 470),
(171, 'sadia', 'Hilsha Fish', 1, 500),
(172, 'sadia', 'Kitkat', 1, 65),
(173, 'sadia', 'Hilsha Fish', 1, 500),
(174, 'sadia', 'Cerelac', 1, 200),
(175, 'sadia', 'Cerelac', 1, 200),
(176, 'sadia', 'Bread', 1, 200),
(177, 'sabiha', 'Broiler Chicken Without Skinwhole', 1, 300),
(178, 'sabiha', 'Broiler Chicken Drumstick', 1, 300),
(179, 'sabiha', 'RD UHT Chocolate Mil', 1, 20);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_img` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `cat_id`, `date`, `product_title`, `product_img`, `product_price`, `product_desc`, `status`) VALUES
(1, 7, '2019-10-07 14:09:59', 'Beef', 'beef.jpg', 470, '<h4 class=\"mtb-title\" style=\"outline: none; margin: 0px auto; padding: 10px 0px 0px; font-family: helveticacondensedbold; font-size: 14px; font-weight: 400; height: 35px; letter-spacing: 1px; overflow: hidden; text-align: center; text-overflow: ellipsis; text-transform: capitalize; white-space: pre-line; width: 175px; background-color: #ffffff;\"><strong>Beef Boneless Without Fat</strong></h4>\r\n<div class=\"mtb-desc\" style=\"outline: none; margin: 0px; padding: 0px; color: #454545; font-family: helveticacondensed; font-size: 12px; height: 15px; text-align: center; letter-spacing: 0.5px; text-transform: lowercase; background-color: #ffffff;\">per kg (+/- 100gm)</div>', 'on'),
(3, 1, '2019-10-07 14:17:33', 'Cerelac', 'cerelac.jpg', 200, '<h4 class=\"mtb-title\" style=\"outline: none; margin: 0px auto; padding: 10px 0px 0px; font-family: helveticacondensedbold; font-size: 14px; font-weight: 400; height: 35px; letter-spacing: 1px; overflow: hidden; text-align: center; text-overflow: ellipsis; text-transform: capitalize; white-space: pre-line; width: 175px; background-color: #ffffff;\"><strong>Cerelac Wheat Mixed Fruit</strong></h4>\r\n<div class=\"mtb-desc\" style=\"outline: none; margin: 0px; padding: 0px; color: #454545; font-family: helveticacondensed; font-size: 12px; height: 15px; text-align: center; letter-spacing: 0.5px; text-transform: lowercase; background-color: #ffffff;\">400 gm (bib)</div>', 'on'),
(4, 11, '2019-10-07 14:18:49', 'Coffee Mate', 'coffeemate.jpg', 200, '<h4 class=\"mtb-title\" style=\"outline: none; margin: 0px auto; padding: 10px 0px 0px; font-family: helveticacondensedbold; font-size: 14px; font-weight: 400; height: 35px; letter-spacing: 1px; overflow: hidden; text-align: center; text-overflow: ellipsis; text-transform: capitalize; white-space: pre-line; width: 175px; background-color: #ffffff;\"><strong>Nestle Coffee Mate Original (Jar)</strong></h4>\r\n<div class=\"mtb-desc\" style=\"outline: none; margin: 0px; padding: 0px; color: #454545; font-family: helveticacondensed; font-size: 12px; height: 15px; text-align: center; letter-spacing: 0.5px; text-transform: lowercase; background-color: #ffffff;\">400 gm</div>', 'on'),
(5, 2, '2019-10-07 14:19:50', 'Kitkat', 'kitkat.jpg', 65, '<h4 class=\"mtb-title\" style=\"outline: none; margin: 0px auto; padding: 10px 0px 0px; font-family: helveticacondensedbold; font-size: 14px; font-weight: 400; height: 35px; letter-spacing: 1px; overflow: hidden; text-align: center; text-overflow: ellipsis; text-transform: capitalize; white-space: pre-line; width: 175px; background-color: #ffffff;\"><strong>Nestle KitKat Chocolate</strong></h4>\r\n<div class=\"mtb-desc\" style=\"outline: none; margin: 0px; padding: 0px; color: #454545; font-family: helveticacondensed; font-size: 12px; height: 15px; text-align: center; letter-spacing: 0.5px; text-transform: lowercase; background-color: #ffffff;\"><strong>27.5 gm</strong></div>', 'on'),
(6, 8, '2019-10-07 14:26:49', 'Bread', 'multigrainbread.jpg', 200, '<p style=\"text-align: center;\"><strong>Multigrain Bread</strong></p>', 'on'),
(7, 10, '2019-10-07 14:28:04', 'Shampoo', 'lorealelviveshampoo.jpg', 550, '<p style=\"text-align: center;\"><strong>lorealelviveshampoo</strong></p>', 'on'),
(8, 7, '2019-10-08 10:11:21', 'Hilsha Fish', 'Hilsha Fish.jpg', 500, '<p style=\"text-align: center;\">This is Hilsha fish</p>', 'on'),
(9, 1, '2019-10-12 21:44:21', 'babywetwipes', 'babywetwipes.jpg', 150, '<p><strong>this is for baby</strong></p>', 'on'),
(10, 1, '2019-10-12 21:49:51', 'johnsonbabymilk', 'johnsonbabymilk.jpg', 170, '<p><strong>Baby Skin Care</strong></p>', 'on'),
(11, 1, '2019-10-12 21:57:41', 'johnsonbabyshampoo', 'johnsonbabyshampoo.jpg', 230, '<p><strong>Shampoo</strong></p>', 'on'),
(12, 1, '2019-10-12 21:58:23', 'lactogen3', 'lactogen3.jpg', 320, '<p><strong>Food</strong></p>', 'on'),
(13, 1, '2019-10-12 21:59:14', 'merilbabyshampoo', 'merilbabyshampoo.jpg', 180, '<p><strong>Shampoo&nbsp;</strong></p>', 'on'),
(14, 1, '2019-10-12 21:59:57', 'nestlenidofortigrow', 'nestlenidofortigrow.jpg', 320, '<p><strong>Baby Food</strong></p>', 'on'),
(15, 1, '2019-10-12 22:00:38', 'pamperspantsdiaper', 'pamperspantsdiaper.jpg', 220, '<p>Baby Skin Care</p>', 'on'),
(16, 1, '2019-10-12 22:01:32', 'Savlonbabydiaper', 'Savlonbabydiaper.jpg', 190, '<p><strong>Baby Skin Care</strong></p>', 'on'),
(17, 2, '2019-10-12 22:05:04', 'amuldarkchoclate', 'amuldarkchoclate.jpg', 385, '<p><strong>150gm</strong></p>', 'on'),
(18, 2, '2019-10-12 22:06:03', 'bountrydouble', 'bountrydouble.jpg', 60, '<p><strong>57gm</strong></p>', 'on'),
(19, 2, '2019-10-12 22:06:51', 'cadburysilk', 'cadburysilk.jpg', 297, '<p><strong>120gm</strong></p>', 'on'),
(20, 2, '2019-10-12 22:07:33', 'centerfresh', 'centerfresh.jpg', 15, '<p><strong>20gm</strong></p>', 'on'),
(21, 2, '2019-10-12 22:08:27', 'hersheyschocsyrup', 'hersheyschocsyrup.jpg', 405, '<p><strong>680gm</strong></p>', 'on'),
(22, 2, '2019-10-12 22:09:04', 'kinderjoy', 'kinderjoy.jpg', 70, '<p><strong>20gm</strong></p>', 'on'),
(23, 2, '2019-10-12 22:09:51', 'nestlecococrunch', 'nestlecococrunch.jpg', 85, '<p><strong>80gm</strong></p>', 'on'),
(24, 2, '2019-10-12 22:10:45', 'SnickersSingle', 'SnickersSingle.jpg', 55, '<p>50gm</p>', 'on'),
(25, 11, '2019-10-12 22:13:48', 'Dan Cake Chocolate Muffin 6 Pcs', 'Dan Cake Chocolate Muffin 6 Pcs.jpg', 220, '<p><strong>100gm</strong></p>', 'on'),
(26, 11, '2019-10-12 22:14:43', 'Dan Cake Chocolate Muffin', 'Dan Cake Chocolate Muffin.jpg', 15, '<p><strong>25gm</strong></p>', 'on'),
(27, 11, '2019-10-12 22:15:44', 'Dan Cake Vanilla Muffin 12 Pcs', 'Dan Cake Vanilla Muffin 12 Pcs.jpg', 180, '<p><strong>25gm</strong></p>', 'on'),
(28, 11, '2019-10-12 22:16:18', 'fad Butter Delight Biscuit', 'fad Butter Delight Biscuit.jpg', 150, '<p><strong>50gm</strong></p>', 'on'),
(29, 11, '2019-10-12 22:17:42', 'Haque Chocolate Digestive Biscuits', 'Haque Chocolate Digestive Biscuits.jpg', 30, '<p><strong>40gm</strong></p>', 'on'),
(30, 11, '2019-10-12 22:19:24', 'Kiswan Chocolate Cookies', 'Kiswan Chocolate Cookies.jpg', 145, '<p><strong>70gm</strong></p>', 'on'),
(31, 11, '2019-10-12 22:20:43', 'Olympic Coconuts Biscuits', 'Olympic Coconuts Biscuits.jpg', 95, '<p><strong>50gm</strong></p>', 'on'),
(32, 11, '2019-10-12 22:21:20', 'oreo', 'oreo.jpg', 95, '<p><strong>25gm</strong></p>', 'on'),
(33, 11, '2019-10-12 22:22:23', 'Bengal Meat Chicken Hot Dog Sausage', 'Bengal Meat Chicken Hot Dog Sausage.jpg', 180, '<p><strong>50gm</strong></p>', 'on'),
(34, 11, '2019-10-12 22:23:10', 'Best`S Mushroom Choice Whole Tin', 'Best`S Mushroom Choice Whole Tin.jpg', 200, '<p><strong>100gm</strong></p>', 'on'),
(35, 11, '2019-10-12 22:23:48', 'CP Chicken Hot Sausage', 'CP Chicken Hot Sausage.jpg', 230, '<p><strong>100gm</strong></p>', 'on'),
(36, 11, '2019-10-12 22:24:36', 'Maggie', 'Maggie.jpg', 250, '<p><strong>500gm</strong></p>', 'on'),
(37, 11, '2019-10-12 22:26:07', 'Maggi Healthy Soup Thai', 'Maggi Healthy Soup Thai.jpg', 140, '<p><strong>30gm</strong></p>', 'on'),
(38, 11, '2019-10-12 22:27:00', 'QUAKER Oats Poly Pack 500 Gm', 'QUAKER Oats Poly Pack 500 Gm.png', 350, '<p><strong>500gm</strong></p>', 'on'),
(39, 11, '2019-10-12 22:29:23', 'pranorangejelly', 'pranorangejelly.jpg', 130, '<p><strong>100gm</strong></p>', 'on'),
(40, 11, '2019-10-12 22:29:57', 'nutellaferrero', 'nutellaferrero.jpg', 300, '<p><strong>200gm</strong></p>', 'on'),
(41, 11, '2019-10-12 22:30:53', 'Ispahani Mirzapur (Poly Bag)', 'Ispahani Mirzapur (Poly Bag).png', 300, '<p><strong>500gm</strong></p>', 'on'),
(42, 11, '2019-10-12 22:31:27', 'fosterMangodrink', 'fosterMangodrink.jpg', 350, '<p>500gm</p>', 'on'),
(43, 11, '2019-10-12 22:32:07', 'Coke(', 'Coke(.jpg', 65, '<p><strong>2ltr</strong></p>', 'on'),
(44, 3, '2019-10-12 22:33:40', 'apple', 'apple.jpg', 160, '<p><strong>1kg</strong></p>', 'on'),
(45, 3, '2019-10-12 22:34:58', 'banana', 'banana.jpg', 50, '<p><strong>25gm</strong></p>', 'on'),
(46, 3, '2019-10-12 22:35:36', 'coconut', 'coconut.jpg', 50, '<p><strong>1</strong></p>', 'on'),
(47, 3, '2019-10-12 22:36:06', 'jambura', 'jambura.jpg', 30, '<p>1</p>', 'on'),
(48, 3, '2019-10-12 22:36:40', 'pomegranate', 'pomegranate.jpg', 50, '<p><strong>1</strong></p>', 'on'),
(49, 3, '2019-10-12 22:37:09', 'sweet orange', 'sweet orange.jpg', 80, '<p><strong>1kg</strong></p>', 'on'),
(50, 3, '2019-10-12 22:37:41', 'aloevera', 'aloevera.jpg', 20, '<p>1</p>', 'on'),
(51, 3, '2019-10-12 22:38:44', 'begun', 'begun.jpg', 20, '<p>1</p>', 'on'),
(52, 3, '2019-10-12 22:39:16', 'borboti', 'borboti.jpg', 30, '<p>20gm</p>', 'on'),
(53, 3, '2019-10-12 22:39:48', 'capsicum', 'capsicum.jpg', 50, '<p>20gm</p>', 'on'),
(54, 3, '2019-10-12 22:41:16', 'lemon', 'lemon.jpg', 15, '<p><strong>20gm</strong></p>', 'on'),
(55, 3, '2019-10-12 22:41:47', 'carrot', 'carrot.jpg', 40, '<p>20gm</p>', 'on'),
(56, 3, '2019-10-12 22:42:31', 'Tomato', 'Tomato.jpg', 40, '<p>1kg</p>', 'on'),
(57, 7, '2019-10-12 22:43:28', 'Bagda Prawn (Chingri)', 'Bagda Prawn (Chingri).jpg', 500, '<p>1kg</p>', 'on'),
(58, 7, '2019-10-12 22:43:57', 'Carpu Fish', 'Carpu Fish.jpg', 200, '<p>1kg</p>', 'on'),
(59, 7, '2019-10-12 22:44:31', 'Rupchanda Big', 'Rupchanda Big.jpg', 600, '<p>1kg</p>', 'on'),
(60, 7, '2019-10-12 22:45:01', 'Rui Deshi (P)', 'Rui Deshi (P).jpg', 400, '<p>1kg</p>', 'on'),
(61, 7, '2019-10-12 22:45:46', 'Broiler Chicken Drumstick', 'Broiler Chicken Drumstick.jpg', 300, '<p>1kg</p>', 'on'),
(62, 7, '2019-10-12 22:46:18', 'Beef Minced Premium (Keema)', 'Beef Minced Premium (Keema).jpg', 350, '<p>1kg</p>', 'on'),
(63, 7, '2019-10-12 22:46:51', 'Mutton Heart (Kolija)', 'Mutton Heart (Kolija).jpg', 400, '<p>1kg</p>', 'on'),
(64, 7, '2019-10-12 22:47:22', 'Broiler Chicken Without Skinwhole', 'Broiler Chicken Without Skinwhole.jpg', 300, '<p>1kg</p>', 'on'),
(65, 7, '2019-10-12 22:47:53', 'BroilerChickenwithSkin', 'BroilerChickenwithSkin.jpg', 350, '<p>1kg</p>', 'on'),
(66, 8, '2019-10-12 22:49:33', 'Aarong Butter', 'Aarong Butter.jpg', 80, '<p>20gm</p>', 'on'),
(67, 8, '2019-10-12 22:50:09', 'Aarong Choco Milk UHT Flav.', 'Aarong Choco Milk UHT Flav..jpg', 20, '<p>20gm</p>', 'on'),
(68, 8, '2019-10-12 22:50:39', 'Aarong Full Cream Milk Powder ', 'Aarong Full Cream Milk Powder .png', 400, '<p>200gm</p>', 'on'),
(69, 8, '2019-10-12 22:51:25', 'Danish Condensed Milk', 'Danish Condensed Milk.jpg', 150, '<p>1kg</p>', 'on'),
(70, 8, '2019-10-12 22:52:15', 'Diploma Instant Full Cream Milk Powder ', 'Diploma Instant Full Cream Milk Powder .jpg', 300, '<p>1kg</p>', 'on'),
(71, 8, '2019-10-12 22:53:27', 'Marks Diet Non Fat Milk Powder (BIB)', 'Marks Diet Non Fat Milk Powder (BIB).jpeg', 300, '<p>1kg</p>', 'on'),
(72, 8, '2019-10-12 22:55:23', 'RD UHT Chocolate Mil', 'RD UHT Chocolate Mil.jpg', 20, '<p>1ltr</p>', 'on'),
(73, 8, '2019-10-12 22:56:27', 'Pran Premium Ghee', 'Pran Premium Ghee.jpg', 200, '<p><strong>1kg</strong></p>', 'on'),
(74, 8, '2019-10-12 22:57:14', 'Aarong Sour Curd', 'Aarong Sour Curd.png', 200, '<p>1kg</p>', 'on'),
(75, 8, '2019-10-12 22:58:00', 'Aarong Sweet Yogurt (Yugurt) 500 Gm', 'Aarong Sweet Yogurt (Yugurt) 500 Gm.png', 230, '<p>1kg</p>', 'on'),
(76, 8, '2019-10-12 23:00:03', 'Aarong Ghee', 'Aarong Ghee.jpg', 200, '<p>1kg</p>', 'on'),
(77, 9, '2019-10-12 23:09:44', 'Onion (Piyaj, Piaz) Indian Loose', 'Onion (Piyaj, Piaz) Indian Loose.jpg', 75, '<p><strong>1kg</strong></p>', 'on'),
(78, 9, '2019-10-12 23:10:32', 'Radhuni Mejbani Beef Masala', 'Radhuni Mejbani Beef Masala.jpg', 150, '<p><strong>1pc</strong></p>', 'on'),
(79, 9, '2019-10-12 23:11:23', 'Radhuni Firni Mix', 'Radhuni Firni Mix.jpg', 170, '<p>1pc</p>', 'on'),
(80, 9, '2019-10-12 23:12:08', 'Radhuni Falooda Mix', 'Radhuni Falooda Mix.jpg', 120, '<p>1pc</p>', 'on'),
(81, 9, '2019-10-12 23:13:09', 'Olatia Oil', 'olatiaOil.jpg', 500, '<p>5ltr</p>', 'on'),
(82, 9, '2019-10-12 23:13:39', 'Garlic (Roshun) China Loose(P)', 'Garlic (Roshun) China Loose(P).jpg', 160, '<p>1kg</p>', 'on'),
(83, 9, '2019-10-12 23:14:07', 'ACI Pure Kheer Mix', 'ACI Pure Kheer Mix.jpg', 200, '<p>1pc</p>', 'on'),
(84, 9, '2019-10-12 23:14:43', 'ACI Pure Halim Mix', 'ACI Pure Halim Mix.jpg', 180, '<p>1pc</p>', 'on'),
(85, 9, '2019-10-12 23:15:14', 'ACI Pure Beef Curry Masala', 'ACI Pure Beef Curry Masala.jpg', 160, '<p><strong>1pc</strong></p>', 'on'),
(86, 10, '2019-10-12 23:20:49', 'Sensodyne Fresh Gel Toothpaste 130gm', 'Sensodyne Fresh Gel Toothpaste 130gm.jpg', 260, '<p>1pc</p>', 'on'),
(87, 10, '2019-10-12 23:21:23', 'TRESemmÃ© Conditioner Keratin Smooth', 'TRESemmÃ© Conditioner Keratin Smooth.jpg', 400, '<p>200gm</p>', 'on'),
(88, 10, '2019-10-12 23:22:02', 'SENSODYNE Toothbrush Ultra Sensitive', 'SENSODYNE Toothbrush Ultra Sensitive.jpg', 85, '<p>1pc</p>', 'on'),
(89, 10, '2019-10-12 23:22:35', 'Parachute Beli Lite', 'Parachute Beli Lite.jpg', 90, '<p>50gm</p>', 'on'),
(90, 10, '2019-10-12 23:23:13', 'PANTENE Anti-Dandruff Shampoo 480 Ml', 'PANTENE Anti-Dandruff Shampoo 480 Ml.jpg', 500, '<p>400gm</p>', 'on'),
(91, 10, '2019-10-12 23:26:16', 'Lever Ayush Face Cream Natural Fairness Saffron', 'Lever Ayush Face Cream Natural Fairness Saffron.jpg', 200, '<p>60gm</p>', 'on'),
(92, 10, '2019-10-12 23:26:47', 'Head & Shoulders Clean & Balanced Shampoo', 'Head & Shoulders Clean & Balanced Shampoo.jpg', 290, '<p>250gm</p>', 'on'),
(93, 10, '2019-10-12 23:27:21', 'Fair And Lovely Fairness Cream Advanced', 'Fair And Lovely Fairness Cream Advanced.jpg', 210, '<p>100gm</p>', 'on'),
(94, 10, '2019-10-12 23:27:57', 'Fair And Lovely Face Cream Blemish Balm', 'Fair And Lovely Face Cream Blemish Balm.jpg', 200, '<p>100gm</p>', 'on'),
(95, 10, '2019-10-12 23:28:28', 'Dabur Almond Hair Oil', 'Dabur Almond Hair Oil.jpg', 300, '<p>100gm</p>', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `email`, `phone`, `password`) VALUES
(1, 'sadia', 'sadiatasnim019@gmail.com', '1954480663', '03c7c0ace395d80182db07ae2c30f034'),
(2, 'sadia', 'sadiatasnim019@gmail.com', '1954480663', '03c7c0ace395d80182db07ae2c30f034'),
(3, 'sadia', 'sadiatasnim019@gmail.com', '1589647896', '03c7c0ace395d80182db07ae2c30f034'),
(4, 'rifat', 'rifat@gmail.com', '1954480663', '4b43b0aee35624cd95b910189b3dc231'),
(5, 'sadiatasnim', 'sadiatasnim019@gmail.com', '1954480663', '03c7c0ace395d80182db07ae2c30f034'),
(6, 'rejwan', 'rejna@gmail.com', '1954480663', '4b43b0aee35624cd95b910189b3dc231'),
(7, 'sabiha', 'sabihabadhon05@gmail.com', '1622772436', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertable`
--
ALTER TABLE `ordertable`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ordertable`
--
ALTER TABLE `ordertable`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
